(() => {
  if (window.__VFC_FACEBOOK_GROUPS_HELPER_BOOTED__) return;
  window.__VFC_FACEBOOK_GROUPS_HELPER_BOOTED__ = true;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function clean(value) {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  function fold(value) {
    return clean(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[’'`]/g, "")
      .toLowerCase();
  }

  function visible(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  }

  function canonicalGroupUrl(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      const parts = url.pathname.split("/").filter(Boolean);
      if (parts[0]?.toLowerCase() !== "groups" || !parts[1]) return "";
      const id = parts[1];
      if (["feed", "discover", "search", "create"].includes(id.toLowerCase())) return "";
      return "https://www.facebook.com/groups/" + id + "/";
    } catch {
      return "";
    }
  }

  function nearestContext(anchor) {
    let node = anchor;
    for (let depth = 0; depth < 7 && node; depth += 1, node = node.parentElement) {
      const text = clean(node.innerText || node.textContent);
      if (text.length >= 20 && text.length <= 1800) return text;
    }
    return clean(anchor.innerText || anchor.textContent);
  }

  function resultName(anchor, context) {
    const direct = clean(anchor.innerText || anchor.textContent || anchor.getAttribute("aria-label"));
    if (direct.length >= 3 && direct.length <= 180) return direct.split("\n")[0];
    const lines = String(context || "").split(/\n+/).map(clean).filter(Boolean);
    return lines.find((line) => line.length >= 3 && line.length <= 180) || "Facebook group";
  }

  function parseMembers(context) {
    const text = clean(context);
    const match = text.match(/([0-9][0-9,.]*\s*[KMB]?)\s+(?:members?|member)/i);
    return match ? clean(match[1]) : "";
  }

  function parsePrivacy(context) {
    if (/\bpublic\s+group\b/i.test(context)) return "Public";
    if (/\bprivate\s+group\b/i.test(context)) return "Private";
    return "";
  }

  async function collectSearchResults(state) {
    for (let index = 0; index < 4; index += 1) {
      window.scrollBy({ top: Math.max(700, window.innerHeight * 0.85), behavior: "smooth" });
      await sleep(850);
    }

    const currentQuery = state?.job?.queries?.[state.queryIndex] || {};
    const seen = new Set();
    const candidates = [];
    const anchors = [...document.querySelectorAll('a[href*="/groups/"]')].filter(visible);

    for (const anchor of anchors) {
      const url = canonicalGroupUrl(anchor.href);
      if (!url || seen.has(url)) continue;
      const context = nearestContext(anchor);
      const name = resultName(anchor, context);
      if (!name || /groups home|discover groups|your groups|create new group/i.test(name)) continue;
      seen.add(url);
      candidates.push({
        name,
        url,
        context: context.slice(0, 1200),
        members: parseMembers(context),
        privacy: parsePrivacy(context),
        segment: currentQuery.segment || "Discovered",
        query: currentQuery.query || "",
      });
      if (candidates.length >= 30) break;
    }

    await chrome.runtime.sendMessage({
      type: "GROUP_DISCOVERY_PAGE_RESULTS",
      jobId: state.job.id,
      queryIndex: state.queryIndex,
      candidates,
    });
  }

  function pageLines() {
    return String(document.body?.innerText || "")
      .split(/\n+/)
      .map(clean)
      .filter(Boolean);
  }

  function contentUnavailable(text) {
    return /this content isn'?t available right now|content is not available|page isn'?t available|group is unavailable|group has been deleted/i.test(String(text || ""));
  }

  function normalizeRegistration(value) {
    return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  }

  function extractRuleEvidence(lines) {
    const keywords = /advert|business|commercial|dealer|promo|link|spam|sell|sale|rule|approval|admin|service/i;
    const results = [];
    const seen = new Set();
    for (const line of lines) {
      if (!keywords.test(line) || line.length < 5 || line.length > 420) continue;
      const key = fold(line);
      if (seen.has(key)) continue;
      seen.add(key);
      results.push(line);
      if (results.length >= 14) break;
    }
    return results.join(" | ");
  }

  function explicitRuleStatus(evidence) {
    const text = fold(evidence);
    if (/no advertising|no advertisements|no business advertising|no business posts|no commercial posts|no dealers|dealers not allowed|no promotional posts/.test(text)) {
      return "Red";
    }
    if (/advertising allowed|business advertising allowed|businesses welcome|promote your business|commercial posts allowed|small businesses welcome/.test(text)) {
      return "Green";
    }
    return "Amber";
  }

  function buttonWithText(pattern) {
    return [...document.querySelectorAll('button, [role="button"], a')]
      .filter(visible)
      .find((element) => pattern.test(clean(element.innerText || element.textContent || element.getAttribute("aria-label"))));
  }

  function findComposerOpener() {
    const direct = buttonWithText(/write something|what'?s on your mind|create post/i);
    if (direct) return direct;

    const label = [...document.querySelectorAll("div, span")]
      .filter(visible)
      .find((element) =>
        /^(write something(?:\.\.\.)?|what'?s on your mind\??)$/i.test(
          clean(element.innerText || element.textContent || element.getAttribute("aria-label")),
        )
      );
    if (!label) return null;
    return label.closest('button, [role="button"]') || label;
  }

  function composerDialog() {
    const dialogs = [...document.querySelectorAll('[role="dialog"]')].filter(visible);
    const createPostDialog = dialogs.find((dialog) =>
      /create post/i.test(clean(dialog.innerText || dialog.textContent || dialog.getAttribute("aria-label")))
    );
    return createPostDialog || dialogs[dialogs.length - 1] || document;
  }

  function composerEditorCandidates(scope) {
    const selectors = [
      '[contenteditable="true"]',
      '[contenteditable="plaintext-only"]',
      '[role="textbox"]',
      '[data-lexical-editor="true"]',
      '[aria-label*="Create a public post"]',
      '[aria-placeholder*="Create a public post"]',
      '[aria-label*="Write something"]',
      '[aria-placeholder*="Write something"]',
    ];

    const candidates = [...new Set(
      selectors.flatMap((selector) => [...scope.querySelectorAll(selector)])
    )].filter(visible);

    return candidates
      .filter((element) => {
        const label = clean([
          element.getAttribute?.("aria-label"),
          element.getAttribute?.("aria-placeholder"),
          element.getAttribute?.("data-placeholder"),
          element.getAttribute?.("placeholder"),
        ].filter(Boolean).join(" "));
        return !/comment|reply|search/i.test(label);
      })
      .sort((first, second) => {
        const score = (element) => {
          let value = 0;
          const label = clean([
            element.getAttribute?.("aria-label"),
            element.getAttribute?.("aria-placeholder"),
            element.getAttribute?.("data-placeholder"),
          ].filter(Boolean).join(" "));
          if (/create a public post|write something|what'?s on your mind/i.test(label)) value += 10;
          if (element.getAttribute?.("role") === "textbox") value += 6;
          if (element.getAttribute?.("contenteditable") === "true") value += 5;
          if (element.getAttribute?.("contenteditable") === "plaintext-only") value += 5;
          if (element.getAttribute?.("data-lexical-editor") === "true") value += 5;
          const rect = element.getBoundingClientRect();
          value += Math.min(8, Math.round((rect.width * rect.height) / 15000));
          return value;
        };
        return score(second) - score(first);
      });
  }

  function editorFromPlaceholder(scope) {
    const labels = [...scope.querySelectorAll("div, span, p")]
      .filter(visible)
      .filter((element) =>
        /^(create a public post|write something|what'?s on your mind)/i.test(
          clean(element.innerText || element.textContent || element.getAttribute("aria-label"))
        )
      );

    for (const label of labels) {
      const ancestor = label.closest(
        '[contenteditable="true"], [contenteditable="plaintext-only"], [role="textbox"], [data-lexical-editor="true"]'
      );
      if (ancestor && visible(ancestor)) return ancestor;

      const parent = label.parentElement;
      const descendant = parent?.querySelector?.(
        '[contenteditable="true"], [contenteditable="plaintext-only"], [role="textbox"], [data-lexical-editor="true"]'
      );
      if (descendant && visible(descendant)) return descendant;
    }
    return null;
  }

  async function waitForComposerEditor(timeoutMs = 6000) {
    const started = Date.now();
    let lastScope = document;

    while (Date.now() - started < timeoutMs) {
      const scope = composerDialog();
      lastScope = scope;

      const direct = composerEditorCandidates(scope)[0];
      if (direct) return { editor: direct, scope };

      const placeholderEditor = editorFromPlaceholder(scope);
      if (placeholderEditor) return { editor: placeholderEditor, scope };

      const placeholder = [...scope.querySelectorAll("div, span, p")]
        .filter(visible)
        .find((element) =>
          /^(create a public post|write something|what'?s on your mind)/i.test(
            clean(element.innerText || element.textContent || element.getAttribute("aria-label"))
          )
        );

      if (placeholder) {
        try { placeholder.click(); } catch {}
        await sleep(180);

        const active = document.activeElement;
        if (
          active &&
          active !== document.body &&
          visible(active) &&
          (
            active.getAttribute?.("role") === "textbox" ||
            active.getAttribute?.("contenteditable") === "true" ||
            active.getAttribute?.("contenteditable") === "plaintext-only" ||
            active.getAttribute?.("data-lexical-editor") === "true"
          )
        ) {
          return { editor: active, scope };
        }
      }

      await sleep(250);
    }

    return { editor: null, scope: lastScope };
  }

  async function inspectGroup(state) {
    await sleep(1800);
    const lines = pageLines();
    const pageText = lines.join("\n").slice(0, 30000);
    const unavailable = contentUnavailable(pageText);
    const ruleEvidence = extractRuleEvidence(lines);
    const canPost = Boolean(
      buttonWithText(/write something|what'?s on your mind|create post/i)
      || [...document.querySelectorAll('[contenteditable="true"][role="textbox"]')].some(visible)
    );
    const joinButton = buttonWithText(/^join(?: group)?$/i);
    const joinedButton = buttonWithText(/^joined$/i);
    const joined = canPost || Boolean(joinedButton) ? true : joinButton ? false : null;
    const approvalRequired = /post approval|requires? approval|pending approval|admin approval/i.test(pageText);
    const linksAllowed = /no external links|links? (?:are )?not allowed|no links/i.test(pageText)
      ? false
      : /links? (?:are )?allowed|website links? allowed/i.test(pageText)
        ? true
        : null;
    const heading = [...document.querySelectorAll("h1, h2")]
      .filter(visible)
      .map((element) => clean(element.innerText || element.textContent))
      .find((value) => value.length >= 3 && value.length <= 180) || "";
    const target = state?.job?.groups?.[state.groupIndex] || {};
    const currentUrl = canonicalGroupUrl(location.href) || canonicalGroupUrl(target.url);

    await chrome.runtime.sendMessage({
      type: "GROUP_INSPECTION_PAGE_RESULT",
      jobId: state.job.id,
      groupIndex: state.groupIndex,
      inspection: {
        name: heading || target.name || "",
        url: currentUrl || target.url || "",
        pageText: pageText.slice(0, 10000),
        ruleEvidence,
        explicitStatus: unavailable ? "Red" : explicitRuleStatus(ruleEvidence),
        unavailable,
        canPost: unavailable ? false : canPost,
        joined,
        approvalRequired,
        linksAllowed,
        privacy: /\bpublic group\b/i.test(pageText) ? "Public" : /\bprivate group\b/i.test(pageText) ? "Private" : "",
        members: parseMembers(pageText),
      },
    });
  }

  async function checkPostedStatus(state) {
    await sleep(2000);
    const target = state?.job?.groups?.[state.groupIndex] || {};
    const pageText = clean(document.body?.innerText || "");
    const unavailable = contentUnavailable(pageText);
    const pending = /pending approval|awaiting approval|waiting for admin approval|post is pending/i.test(pageText);
    const wantedReg = normalizeRegistration(target.registration);

    const resultAnchors = [...document.querySelectorAll(
      'a[href*="/posts/"], a[href*="/permalink/"], a[href*="/groups/"][href*="posts"]'
    )].filter(visible);

    let accepted = false;
    let matchedUrl = "";
    if (!unavailable && wantedReg) {
      for (const anchor of resultAnchors) {
        const context = nearestContext(anchor);
        if (normalizeRegistration(context).includes(wantedReg)) {
          accepted = true;
          matchedUrl = anchor.href || "";
          break;
        }
      }
    }

    await chrome.runtime.sendMessage({
      type: "GROUP_POST_STATUS_PAGE_RESULT",
      jobId: state.job.id,
      groupIndex: state.groupIndex,
      result: {
        name: target.name || "",
        url: canonicalGroupUrl(target.url) || canonicalGroupUrl(location.href),
        registration: target.registration || "",
        accepted,
        pending: !accepted && pending,
        unavailable,
        matchedUrl,
        checkedAt: new Date().toISOString(),
      },
    });
  }

  function reactSetText(element, value) {
    element.focus();
    try {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
    } catch {
      element.textContent = value;
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    }
  }

  function dataUrlToFile(dataUrl, filename) {
    const parts = String(dataUrl || "").split(",");
    const header = parts[0] || "";
    const base64 = parts[1] || "";
    const mime = header.match(/data:([^;]+)/)?.[1] || "image/jpeg";
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return new File([bytes], filename, { type: mime });
  }

  async function attachImage(job, dialog) {
    if (!job.imageUrl) return { ok: true, detail: "No image supplied" };
    let input = [...(dialog || document).querySelectorAll('input[type="file"]')]
      .find((element) => String(element.accept || "").includes("image") || !element.accept);

    if (!input) {
      const photoButton = [...(dialog || document).querySelectorAll('button, [role="button"]')]
        .filter(visible)
        .find((element) => /photo|video/i.test(clean(element.innerText || element.textContent || element.getAttribute("aria-label"))));
      if (photoButton) {
        photoButton.click();
        await sleep(800);
        input = [...document.querySelectorAll('input[type="file"]')]
          .find((element) => String(element.accept || "").includes("image") || !element.accept);
      }
    }
    if (!input) return { ok: false, detail: "Photo input not found" };

    const result = await chrome.runtime.sendMessage({ type: "FETCH_MARKETPLACE_IMAGE", url: job.imageUrl });
    if (!result?.ok || !result.dataUrl) return { ok: false, detail: result?.error || "Image fetch failed" };
    const transfer = new DataTransfer();
    transfer.items.add(dataUrlToFile(result.dataUrl, (job.registration || "van") + "-group.jpg"));
    input.files = transfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await sleep(1200);
    return { ok: true, detail: "Image attached" };
  }

  function showPostReport(job, results) {
    document.getElementById("vfc-group-helper-report")?.remove();
    const panel = document.createElement("div");
    panel.id = "vfc-group-helper-report";
    panel.style.cssText = [
      "position:fixed",
      "right:18px",
      "bottom:18px",
      "z-index:2147483647",
      "width:min(430px,calc(100vw - 36px))",
      "background:#111",
      "color:#fff",
      "border:2px solid #e31b23",
      "border-radius:12px",
      "padding:14px",
      "font:14px/1.45 Arial,sans-serif",
      "box-shadow:0 12px 35px rgba(0,0,0,.45)",
    ].join(";");
    const failed = results.filter((item) => !item.ok);
    const failureHtml = failed.length
      ? '<div style="margin-top:8px;color:#ffd5d5"><b>Needs attention:</b><br>' + failed.map((item) => "• " + item.label + ": " + item.detail).join("<br>") + "</div>"
      : '<div style="margin-top:8px;color:#bfffc8"><b>Post is prepared for review.</b></div>';
    panel.innerHTML =
      '<div style="font-size:16px;font-weight:700">VFC Facebook Groups Helper</div>' +
      '<div style="margin-top:4px">' + (job.groupName || "Facebook group") + " • " + (job.registration || "selected van") + "</div>" +
      '<div style="margin-top:8px">' + results.filter((item) => item.ok).length + "/" + results.length + " preparation checks succeeded.</div>" +
      failureHtml +
      '<div style="margin-top:10px;color:#ddd"><b>Nothing has been posted.</b> Check the group rules and advert, then click Facebook\'s Post button yourself.</div>';
    document.body.appendChild(panel);
  }

  function watchManualGroupPost(job, dialog) {
    let sent = false;

    async function onClick(event) {
      if (sent) return;
      const button = event.target?.closest?.('button, [role="button"]');
      if (!button || !visible(button)) return;
      if (dialog && dialog !== document && !dialog.contains(button)) return;
      const label = clean(button.innerText || button.textContent || button.getAttribute("aria-label"));
      if (!/^post(?:\s|$)/i.test(label)) return;
      if (button.disabled || button.getAttribute("aria-disabled") === "true") return;

      sent = true;
      await sleep(1800);
      const pageText = clean(document.body?.innerText || "");
      const approvalState = /pending approval|awaiting approval|waiting for admin approval|post is pending/i.test(pageText)
        ? "pending"
        : "submitted";

      chrome.runtime.sendMessage({
        type: "GROUP_POST_SUBMITTED",
        jobId: job.id,
        groupUrl: canonicalGroupUrl(job.groupUrl),
        registration: job.registration || "",
        postedAt: new Date().toISOString(),
        approvalState,
      }).catch(() => {});
    }

    document.addEventListener("click", onClick, true);
    window.setTimeout(() => document.removeEventListener("click", onClick, true), 15 * 60 * 1000);
  }

  async function prepareGroupPost(job) {
    if (!location.pathname.startsWith("/groups/")) return;
    await sleep(1200);
    const results = [];

    let { editor, scope } = await waitForComposerEditor(1200);
    if (!editor) {
      const opener = findComposerOpener();
      if (opener) {
        try { opener.click(); } catch {}
        results.push({ label: "Composer", ok: true, detail: "Opened" });
        ({ editor, scope } = await waitForComposerEditor(6500));
      } else {
        results.push({ label: "Composer", ok: false, detail: "Write something / Create post control not found" });
      }
    } else {
      results.push({ label: "Composer", ok: true, detail: "Already open" });
    }

    if (editor) {
      reactSetText(editor, job.caption || "");
      await sleep(700);
      results.push({
        label: "Post text",
        ok: clean(editor.innerText || editor.textContent).length > 10,
        detail: "Caption inserted",
      });
    } else {
      results.push({ label: "Post text", ok: false, detail: "Composer text box not found after opening the post dialog" });
    }

    const composerOpened = scope !== document || Boolean(composerDialog() !== document);
    const imageResult = composerOpened
      ? await attachImage(job, scope)
      : { ok: false, detail: "Skipped because the post composer did not open" };
    results.push({ label: "Photo", ok: imageResult.ok, detail: imageResult.detail });

    if (editor) watchManualGroupPost(job, scope);
    showPostReport(job, results);
    await chrome.runtime.sendMessage({ type: "GROUP_POST_FILL_COMPLETED", jobId: job.id, results });
  }

  (async () => {
    const postResult = await chrome.runtime.sendMessage({ type: "GET_PENDING_GROUP_POST_JOB" }).catch(() => null);
    const job = postResult?.job || null;
    if (job?.id && location.pathname.startsWith("/groups/")) {
      await prepareGroupPost(job);
      return;
    }

    const stateResult = await chrome.runtime.sendMessage({ type: "GET_GROUP_AGENT_STATE" }).catch(() => null);
    const state = stateResult?.state || null;

    if (
      state?.mode === "discovery" &&
      (location.pathname.startsWith("/search/groups") || location.pathname.startsWith("/groups/search"))
    ) {
      await sleep(1600);
      await collectSearchResults(state);
      return;
    }

    if (state?.mode === "inspection" && location.pathname.startsWith("/groups/")) {
      await inspectGroup(state);
      return;
    }

    if (
      (state?.mode === "post-status" || state?.mode === "auto-post-status") &&
      location.pathname.startsWith("/groups/")
    ) {
      await checkPostedStatus(state);
    }
  })().catch((error) => {
    console.error("VFC Facebook Groups Helper failed", error);
  });
})();
